window.addEventListener('load', function() {

	// usability enhancement: focus the delete button
	document.getElementById('btnSubmit').focus();

});

// EOF
